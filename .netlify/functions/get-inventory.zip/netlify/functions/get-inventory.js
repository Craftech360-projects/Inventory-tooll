// netlify/functions/get-inventory.js
var APPS_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbxGpuUe8AkkQCrO9zB4uolgX2smc_Ih66k8VXrlWdB3794D5YuYckhaAoTq6TcozOHT/exec";
exports.handler = async (event, context) => {
  try {
    const response = await fetch(APPS_SCRIPT_URL + "?action=getInventory&_=" + Date.now());
    const data = await response.json();
    if (!data || data.length === 0) {
      return {
        statusCode: 200,
        headers: {
          "Content-Type": "text/csv",
          "Access-Control-Allow-Origin": "*",
          "Cache-Control": "no-cache"
        },
        body: "Item ID,Item Name,Category,Quantity,Status,Location,Value (\u20B9),Added Date,Notes\n"
      };
    }
    const headers = data[0];
    const csvRows = [headers.join(",")];
    for (let i = 1; i < data.length; i++) {
      const row = data[i];
      const values = row.map((val) => {
        if (val === null || val === void 0 || val === "") return "";
        const str = String(val).replace(/"/g, '""');
        return str.includes(",") ? `"${str}"` : str;
      });
      csvRows.push(values.join(","));
    }
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "text/csv",
        "Access-Control-Allow-Origin": "*",
        "Cache-Control": "no-cache, no-store, must-revalidate"
      },
      body: csvRows.join("\n")
    };
  } catch (error) {
    return {
      statusCode: 500,
      headers: {
        "Content-Type": "application/json",
        "Access-Control-Allow-Origin": "*"
      },
      body: JSON.stringify({ error: error.message, stack: error.stack })
    };
  }
};
