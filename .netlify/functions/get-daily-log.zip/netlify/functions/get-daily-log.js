// netlify/functions/get-daily-log.js
var SHEET_CSV_URL = "https://docs.google.com/spreadsheets/d/1MrwDU0XtemyfpwWNX551ulfUIAFECB4cLCPhNJH1yuo/export?format=csv&gid=";
exports.handler = async (event, context) => {
  try {
    const response = await fetch(SHEET_CSV_URL + "DailyLog", {
      headers: {
        "Cache-Control": "no-cache, no-store, must-revalidate",
        "Pragma": "no-cache"
      }
    });
    if (!response.ok) {
      return {
        statusCode: 200,
        headers: {
          "Content-Type": "text/csv",
          "Access-Control-Allow-Origin": "*"
        },
        body: "Log ID,Item ID,Item Name,Team Member,Purpose,Request Date,Expected Return,Status,Handed Over By,Handover Date,Return Date,Notes"
      };
    }
    const csvText = await response.text();
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "text/csv",
        "Access-Control-Allow-Origin": "*",
        "Cache-Control": "no-cache, no-store, must-revalidate"
      },
      body: csvText
    };
  } catch (error) {
    return {
      statusCode: 200,
      headers: {
        "Content-Type": "text/csv",
        "Access-Control-Allow-Origin": "*"
      },
      body: "Log ID,Item ID,Item Name,Team Member,Purpose,Request Date,Expected Return,Status,Handed Over By,Handover Date,Return Date,Notes"
    };
  }
};
